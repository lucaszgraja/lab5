angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('tabsController.glowna', {
    url: '/page5',
    views: {
      'tab4': {
        templateUrl: 'templates/glowna.html',
        controller: 'glownaCtrl'
      }
    }
  })

  .state('tabsController.wyborWydzialu', {
    url: '/page6',
    views: {
      'tab4': {
        templateUrl: 'templates/wyborWydzialu.html',
        controller: 'wyborWydzialuCtrl'
      }
    }
  })

  .state('tabsController.nawigacyjny', {
    url: '/page7',
    views: {
      'tab4': {
        templateUrl: 'templates/nawigacyjny.html',
        controller: 'nawigacyjnyCtrl'
      }
    }
  })

  .state('tabsController.wPIT', {
    url: '/page8',
    views: {
      'tab4': {
        templateUrl: 'templates/wPIT.html',
        controller: 'wPITCtrl'
      }
    }
  })

  .state('tabsController.elektryczny', {
    url: '/page9',
    views: {
      'tab4': {
        templateUrl: 'templates/elektryczny.html',
        controller: 'elektrycznyCtrl'
      }
    }
  })

  .state('tabsController.mechaniczny', {
    url: '/page10',
    views: {
      'tab4': {
        templateUrl: 'templates/mechaniczny.html',
        controller: 'mechanicznyCtrl'
      }
    }
  })

  .state('tabsController.studiuj', {
    url: '/page11',
    views: {
      'tab4': {
        templateUrl: 'templates/studiuj.html',
        controller: 'studiujCtrl'
      }
    }
  })

  .state('tabsController.przegrales', {
    url: '/page12',
    views: {
      'tab4': {
        templateUrl: 'templates/przegrales.html',
        controller: 'przegralesCtrl'
      }
    }
  })

  .state('tabsController.wygraEs', {
    url: '/page16',
    views: {
      'tab4': {
        templateUrl: 'templates/wygraEs.html',
        controller: 'wygraEsCtrl'
      }
    }
  })

  .state('tabsController.pytanie1', {
    url: '/page13',
    views: {
      'tab4': {
        templateUrl: 'templates/pytanie1.html',
        controller: 'pytanie1Ctrl'
      }
    }
  })

  .state('tabsController.pytanie2', {
    url: '/page14',
    views: {
      'tab4': {
        templateUrl: 'templates/pytanie2.html',
        controller: 'pytanie2Ctrl'
      }
    }
  })

  .state('tabsController.pytanie3', {
    url: '/page15',
    views: {
      'tab4': {
        templateUrl: 'templates/pytanie3.html',
        controller: 'pytanie3Ctrl'
      }
    }
  })

  .state('tabsController.galeria', {
    url: '/page17',
    views: {
      'tab4': {
        templateUrl: 'templates/galeria.html',
        controller: 'galeriaCtrl'
      }
    }
  })

$urlRouterProvider.otherwise('/page1/page5')

  

});